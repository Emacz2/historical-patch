Music.prototype.resetTracks = function()
{
	this.tracks = {
		"MENU": ["historical_anthem.ogg"],
		"PEACE": [],
		"BATTLE": ["Taiko_1.ogg", "Taiko_2.ogg"],
		"VICTORY": ["You_are_Victorious!.ogg"],
		"DEFEAT": ["Hero_Down-lost.ogg"],
		"CUSTOM": []
	};
};
